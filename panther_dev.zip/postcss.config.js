module.export = {
    plugins: {
        '@tailwindcss/jit': {},
        autoprefixer: {}
      },
}